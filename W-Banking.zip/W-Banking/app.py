import os, sqlite3, secrets, hashlib, time
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-for-production")
DB = os.path.join(app.instance_path, "banking.sqlite3")
FLAG = os.environ.get("CTF_FLAG", "WB{otp_parameter_pollution_banked_it}")

# Lab-only accounts. Attacker credentials are documented in README.md, not in the UI/source templates.
ATTACKER_EMAIL = "alex.morgan@example.test"
ATTACKER_PASSWORD = "BlueCyan!4821"
VICTIM_EMAIL = "jordan.reed@example.test"


def db():
    os.makedirs(app.instance_path, exist_ok=True)
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      balance INTEGER NOT NULL DEFAULT 12450
    );
    CREATE TABLE IF NOT EXISTS otps(
      id INTEGER PRIMARY KEY,
      account_email TEXT NOT NULL,
      otp TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      used INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS mail_messages(
      id INTEGER PRIMARY KEY,
      recipient_email TEXT NOT NULL,
      account_email TEXT NOT NULL,
      otp TEXT NOT NULL,
      subject TEXT NOT NULL,
      created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS transfers(
      id INTEGER PRIMARY KEY,
      user_id INTEGER NOT NULL,
      recipient TEXT NOT NULL,
      amount INTEGER NOT NULL,
      note TEXT NOT NULL,
      created_at INTEGER NOT NULL
    );
    """)

    if not c.execute("SELECT 1 FROM users WHERE email=?", (ATTACKER_EMAIL,)).fetchone():
        c.execute(
            "INSERT INTO users(email,name,password_hash,balance) VALUES(?,?,?,?)",
            (ATTACKER_EMAIL, "Alex Morgan", hashlib.sha256(ATTACKER_PASSWORD.encode()).hexdigest(), 12450),
        )

    if not c.execute("SELECT 1 FROM users WHERE email=?", (VICTIM_EMAIL,)).fetchone():
        # The victim password is deliberately not surfaced by the application.
        victim_password = secrets.token_urlsafe(18)
        c.execute(
            "INSERT INTO users(email,name,password_hash,balance) VALUES(?,?,?,?)",
            (VICTIM_EMAIL, "Jordan Reed", hashlib.sha256(victim_password.encode()).hexdigest(), 18760),
        )

    c.commit()
    c.close()


@app.before_request
def setup():
    init_db()


@app.context_processor
def common():
    return {"year": datetime.now().year, "logged_in": "user_id" in session}


@app.route("/")
def home():
    return render_template("home.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        c = db()
        u = c.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        c.close()
        if u and hashlib.sha256(password.encode()).hexdigest() == u["password_hash"]:
            session["user_id"] = u["id"]
            session["email"] = u["email"]
            session["name"] = u["name"]
            if u["email"] == VICTIM_EMAIL:
                c2 = db()
                transfer_count = c2.execute("SELECT COUNT(*) FROM transfers WHERE user_id=?", (u["id"],)).fetchone()[0]
                c2.close()
                if transfer_count >= 3:
                    session["flag_unlocked"] = True
                else:
                    session.pop("flag_unlocked", None)
            else:
                session.pop("flag_unlocked", None)
            return redirect(url_for("dashboard"))
        flash("We couldn't verify those credentials. Please check your email and password.")
    return render_template("login.html")


@app.route("/register")
def register():
    flash("Registrations are currently closed while we complete a scheduled platform update.")
    return redirect(url_for("login"))


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot():
    if request.method == "POST":
        # INTENTIONAL CTF BUG:
        # The recipient parameter is expected to be a single email string, but the
        # backend also accepts a JSON array in that same parameter. Every valid account
        # in the submitted array receives its own fresh account-specific OTP, while
        # each OTP is delivered to EVERY submitted recipient. Example Burp edit:
        #   email=["attacker@example.test","victim@example.test"]
        # This causes the attacker mailbox to receive the victim account's fresh OTP.
        raw_form = request.form.get("email", "").strip()
        emails = []
        if raw_form:
            try:
                parsed = __import__("json").loads(raw_form)
            except (ValueError, TypeError):
                parsed = raw_form
            if isinstance(parsed, list):
                emails = [str(x).strip().lower() for x in parsed if str(x).strip()]
            else:
                emails = [str(parsed).strip().lower()] if str(parsed).strip() else []

        if not emails:
            # Keep JSON support for API-style clients, but the normal UI uses a form so
            # the request is easy for Burp Suite / OWASP ZAP to intercept and edit.
            data = request.get_json(silent=True)
            if isinstance(data, dict):
                raw = data.get("email", [])
                if isinstance(raw, list):
                    emails = [str(x).strip().lower() for x in raw if str(x).strip()]
                elif raw:
                    emails = [str(raw).strip().lower()]

        if not emails:
            flash("Enter an email address.")
            return redirect(url_for("forgot"))

        # Preserve order but remove duplicate recipient values.
        emails = list(dict.fromkeys(emails))
        c = db()
        valid_accounts = []
        for email in emails:
            u = c.execute("SELECT email FROM users WHERE email=?", (email,)).fetchone()
            if u:
                valid_accounts.append(email)

        now = int(time.time())
        # INTENTIONAL CTF BUG: every valid account in the polluted recipient list
        # gets its own fresh, account-specific OTP. Each generated OTP is delivered
        # to every submitted recipient. This means the attacker can receive both
        # codes, but an OTP for one account can never reset the other account.
        for account_email in valid_accounts:
            # A new request replaces the previous active code for this account.
            c.execute("UPDATE otps SET used=1 WHERE account_email=? AND used=0", (account_email,))
            otp = f"{secrets.randbelow(1_000_000):06d}"
            c.execute(
                "INSERT INTO otps(account_email,otp,created_at) VALUES(?,?,?)",
                (account_email, otp, now),
            )
            subject = "Your W Banking verification code"
            for recipient in emails:
                c.execute(
                    "INSERT INTO mail_messages(recipient_email,account_email,otp,subject,created_at) VALUES(?,?,?,?,?)",
                    (recipient, account_email, otp, subject, now),
                )

        c.commit()
        c.close()
        # Deliberately do NOT return OTPs in the HTTP response. The intended learning path
        # is to observe the request in Burp/ZAP and then inspect the attacker's local mailbox.
        flash("If the account exists, a verification code has been sent to the registered email address.")
        return redirect(url_for("forgot"))

    return render_template("forgot.html")


@app.route("/reset-password", methods=["GET", "POST"])
def reset():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        otp = request.form.get("otp", "").strip()
        # Keep verification strict but normalize harmless formatting from copied codes.
        otp = "".join(ch for ch in otp if ch.isdigit())
        newpass = request.form.get("new_password", "")
        if len(newpass) < 10:
            flash("Please choose a password with at least 10 characters.")
            return redirect(url_for("reset"))

        c = db()
        row = c.execute(
            """SELECT * FROM otps
               WHERE account_email=? AND otp=? AND used=0
               ORDER BY id DESC LIMIT 1""",
            (email, otp),
        ).fetchone()
        if not row:
            c.close()
            flash("That verification code is invalid or has expired for this account.")
            return redirect(url_for("reset"))

        c.execute(
            "UPDATE users SET password_hash=? WHERE email=?",
            (hashlib.sha256(newpass.encode()).hexdigest(), email),
        )
        c.execute("UPDATE otps SET used=1 WHERE id=?", (row["id"],))
        c.commit()
        c.close()
        flash("Your password has been updated. You can now sign in.")
        return redirect(url_for("login"))

    return render_template("reset.html")


@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect(url_for("login"))
    c = db()
    u = c.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    tx = c.execute("SELECT * FROM transfers WHERE user_id=? ORDER BY id DESC LIMIT 8", (u["id"],)).fetchall()
    transfer_count = c.execute("SELECT COUNT(*) FROM transfers WHERE user_id=?", (u["id"],)).fetchone()[0]
    if u["email"] == VICTIM_EMAIL and transfer_count >= 3:
        session["flag_unlocked"] = True
    c.close()
    return render_template("dashboard.html", user=u, transfers=tx, flag=FLAG)


@app.route("/transfer", methods=["POST"])
def transfer():
    if "user_id" not in session:
        return redirect(url_for("login"))

    recipient = request.form.get("recipient", "").strip()
    try:
        amount = int(request.form.get("amount", "0"))
    except ValueError:
        amount = 0
    note = request.form.get("note", "").strip()

    c = db()
    u = c.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    if amount <= 0 or amount > u["balance"]:
        flash("Please enter a valid amount within your available balance.")
    elif not recipient:
        flash("Please enter a recipient.")
    else:
        c.execute("UPDATE users SET balance=balance-? WHERE id=?", (amount, u["id"]))
        c.execute(
            "INSERT INTO transfers(user_id,recipient,amount,note,created_at) VALUES(?,?,?,?,?)",
            (u["id"], recipient, amount, note, int(time.time())),
        )
        c.commit()
        if u["email"] == VICTIM_EMAIL:
            count = c.execute("SELECT COUNT(*) FROM transfers WHERE user_id=?", (u["id"],)).fetchone()[0]
            if count >= 3:
                session["flag_unlocked"] = True
        flash("Transfer submitted successfully.")
    c.close()
    return redirect(url_for("dashboard"))


@app.route("/flag")
def flag():
    if session.get("email") != VICTIM_EMAIL or not session.get("flag_unlocked"):
        return "Not found", 404
    return jsonify(flag=FLAG)


@app.route("/mail/<mailbox>")
def mailbox(mailbox):
    if mailbox not in ("attacker", "victim"):
        return "Not found", 404
    if mailbox == "victim" and session.get("email") != VICTIM_EMAIL:
        return render_template("mail_locked.html")

    target = ATTACKER_EMAIL if mailbox == "attacker" else VICTIM_EMAIL
    c = db()
    rows = c.execute(
        """SELECT * FROM mail_messages
           WHERE recipient_email=?
           ORDER BY id DESC LIMIT 20""",
        (target,),
    ).fetchall()
    c.close()
    return render_template("mail.html", mailbox=mailbox, emails=rows, target=target)


@app.route("/contact")
def contact():
    return render_template("contact.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


if __name__ == "__main__":
    init_db()
    # 0.0.0.0 lets the lab be reached through a local hostname or LAN interface.
    # The README recommends a hosts-file alias for browsers configured with Burp/ZAP,
    # because some browsers bypass their proxy for literal localhost/127.0.0.1 URLs.
    app.run(host="0.0.0.0", port=5000, debug=False)
